package com.example.spiritdetector

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioRecord
import android.media.AudioFormat
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt
import kotlin.math.abs
import kotlin.concurrent.thread

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var magnetometer: Sensor? = null
    private lateinit var magneticText: TextView
    private lateinit var activityText: TextView
    private lateinit var radar: RadarView
    private lateinit var audioButton: Button
    private var baseline: Float? = null
    private var latest = 0f
    private var recording = false
    private var recorder: AudioRecord? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(5, 10, 13))
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        magnetometer = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 20); setBackgroundColor(Color.rgb(5,10,13))
        }
        root.addView(label("SPIRIT DETECTOR", 28f, Color.rgb(70,255,155)))
        root.addView(label("OBSERVATION DES PHÉNOMÈNES", 12f, Color.LTGRAY))
        radar = RadarView(this)
        root.addView(radar, LinearLayout.LayoutParams(300, 300))
        magneticText = label("Champ magnétique : en attente…", 17f, Color.WHITE)
        root.addView(magneticText)
        activityText = label("Activité mesurée : —", 17f, Color.rgb(70,255,155))
        root.addView(activityText)
        audioButton = Button(this).apply { text = "ACTIVER L’ANALYSE SONORE"; setOnClickListener { toggleAudio() } }
        root.addView(audioButton)
        root.addView(label("Important : cette application mesure des phénomènes physiques. Elle ne peut pas prouver la présence d’un esprit.", 13f, Color.LTGRAY))
        root.addView(label("Éloigne le téléphone des aimants, haut-parleurs et objets métalliques pour réduire les perturbations.", 12f, Color.GRAY))
        setContentView(root)
        if (magnetometer == null) magneticText.text = "Magnétomètre non disponible sur ce téléphone."
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        setPadding(4, 8, 4, 8)
    }

    override fun onResume() { super.onResume(); magnetometer?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    override fun onPause() { super.onPause(); sm.unregisterListener(this); stopAudio() }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD) return
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val strength = sqrt(x*x + y*y + z*z)
        latest = strength
        if (baseline == null) baseline = strength
        // Slow-moving baseline avoids labeling every ordinary fluctuation as an anomaly.
        baseline = baseline!! * 0.98f + strength * 0.02f
        val deviation = abs(strength - baseline!!)
        val level = (deviation / 15f * 100f).toInt().coerceIn(0, 100)
        magneticText.text = "Champ magnétique : %.1f µT\nX %.1f | Y %.1f | Z %.1f".format(strength, x, y, z)
        activityText.text = "Variation mesurée : $level / 100"
        radar.setLevel(level)
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun toggleAudio() {
        if (recording) { stopAudio(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 22); return
        }
        val min = AudioRecord.getMinBufferSize(8000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(this, "Microphone non disponible", Toast.LENGTH_SHORT).show(); return }
        try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, 8000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            recorder?.startRecording(); recording = true; audioButton.text = "ARRÊTER L’ANALYSE SONORE"
            thread {
                val data = ShortArray(min / 2)
                while (recording) {
                    val n = recorder?.read(data, 0, data.size) ?: 0
                    if (n > 0) {
                        var sum = 0.0
                        for (i in 0 until n) { val v = data[i].toDouble(); sum += v*v }
                        val rms = sqrt(sum / n).toInt()
                        handler.post { if (recording) activityText.text = "Niveau sonore mesuré : $rms (valeur relative)" }
                    }
                }
            }
        } catch (e: Exception) { stopAudio(); Toast.makeText(this, "Impossible d’activer le microphone", Toast.LENGTH_LONG).show() }
    }
    private fun stopAudio() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        if (::audioButton.isInitialized) audioButton.text = "ACTIVER L’ANALYSE SONORE"
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggleAudio()
        else Toast.makeText(this, "Autorisation microphone refusée", Toast.LENGTH_SHORT).show()
    }
}
