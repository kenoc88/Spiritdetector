package com.example.spiritdetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View

class RadarView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var level = 0
    private var phase = 0f
    fun setLevel(v: Int) { level = v; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) * .42f
        canvas.drawColor(Color.rgb(5,10,13))
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.rgb(35,120,83)
        for (f in listOf(.28f, .52f, .76f, 1f)) canvas.drawCircle(cx, cy, r*f, p)
        canvas.drawLine(cx-r, cy, cx+r, cy, p); canvas.drawLine(cx, cy-r, cx, cy+r, p)
        p.color = Color.argb(70, 70, 255, 155); p.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, r * (level / 100f), p)
        p.color = Color.rgb(70,255,155); p.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, 7f, p)
        p.color = Color.WHITE; p.textSize = 25f; p.textAlign = Paint.Align.CENTER
        canvas.drawText("${level}%", cx, cy + r + 34f, p)
    }
}
