# Spirit Detector (Android)

Projet Android hors ligne, en français. Il affiche les mesures du magnétomètre (si le téléphone en possède un) et permet une analyse simple du niveau sonore avec autorisation du microphone.

**Limite importante :** aucune de ces mesures ne détecte ou ne prouve la présence d'un esprit. Le champ magnétique peut varier à cause des aimants, haut-parleurs, câbles électriques et objets métalliques. Le niveau sonore n'identifie pas l'origine d'un son.

## Générer l'APK
1. Sur un ordinateur, installer Android Studio depuis le site officiel Android Developers.
2. Ouvrir le dossier `SpiritDetector` dans Android Studio.
3. Laisser Gradle synchroniser le projet et installer les composants SDK proposés.
4. Choisir **Build > Build APK(s)**.
5. L'APK de débogage sera généralement créé dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Transférer l'APK sur le téléphone Android et l'ouvrir. Autoriser l'installation depuis cette source si Android le demande, puis confirmer l'installation.

La génération de l'APK nécessite Android SDK/Gradle et n'a pas été effectuée dans cet environnement.
